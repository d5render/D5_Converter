D5A_BLENDER_PLUGIN_VERSION = "0.6.0"
UPDATE_CHECK_URL = "https://usa.fusion.d5techs.com/api/plugins/check-version?pluginType=1"
UPDATE_DOWNLOAD_URL = "http://usa.d5converter.d5cdn.com/update/"