# TODO: Add GPL License Here

bl_info = {
    "name": "D5A Format",
    "description": "Export to D5A Format",
    "author": "DIMENSION 5",
    "version": (0, 6, 0),
    "blender": (2, 82, 0),
    "location": "File > Export",
    "support": "COMMUNITY",
    "category": "Import-Export"
}


if "bpy" in locals():
    import importlib
    if "d5a_export" in locals():
        importlib.reload(d5a_export)
    if "d5a_material" in locals():
        importlib.reload(d5a_material)


import bpy
from bpy.props import StringProperty, BoolProperty, FloatProperty, EnumProperty, CollectionProperty, IntProperty
from bpy_extras.io_utils import ExportHelper


class ExportD5A(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.d5a"
    bl_label = "Export D5A"
    
    filename_ext = ".d5a"
    filter_glob: StringProperty(default="*.d5a", options={'HIDDEN'})

    textureSize: IntProperty(default=1024, name="Texture Size: ", min=256, max=4096, step=256)
    exportSelected: BoolProperty(default=False, name="Export Selected: ")
    bakeGroupNodes: BoolProperty(default=True, name="Bake Group Nodes: ")
    # useTransform: BoolProperty(default=True, name="Apply Transform: ")
    writeLog: BoolProperty(default=False, name="Debug Mode: ")
    # bakeTextures: BoolProperty(default=False, name="Bake Textures: ")

    def execute(self, context):
        self.report({'INFO'}, "Saving D5A File To: " + self.filepath)

        from . import d5a_export
        from . import d5a_update

        result = d5a_export.ExportD5AMain(self.filepath, self.textureSize, self.exportSelected, self.bakeGroupNodes, self.writeLog) 
        if result != None:
            self.report({'ERROR'}, result)

        result = d5a_update.UpdatePlugin()
        if result != None:
            self.report({'INFO'}, result)

        return {'FINISHED'}


def menu_func_export(self, context):
    self.layout.operator(ExportD5A.bl_idname, text="D5A (.d5a)")

classes = (
    ExportD5A,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    return

def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in classes:
        bpy.utils.unregister_class(cls)
    return


if __name__ == "__main__":
    register()
