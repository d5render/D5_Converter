import io
import math
import os
import random
import re
import shutil
import time
import zipfile
import traceback
import numpy as np
import bpy
import bmesh
import gc
from typing import List, Tuple, Dict, Any, overload
from .d5a_material import *
from .PIL import Image


# ----------------------------------------------
# Begin - Global Variables

gDebugMode: bool = True
gLogFile = None

goFilePath: str = None
goTextureSize: int = 1024
goExportSelected: bool = False
goUseTransform: bool = False
goBakeGroupNodes: bool = True

gIamgeFormat: str = ".png"

gTempDir: str = None
gTextureDir: str = None
gCurrentMaterial: bpy.types.Material = None

gMaterialMappers = {}
gTextureMappers = {}
gValueMappers = {}

# End - Global Variables
# ----------------------------------------------


# ----------------------------------------------
# Begin - Helpers

def Log(message) -> None:
    if not gDebugMode:
        return

    t = time.time()
    lt = time.localtime()
    timeStr = "%02d:%02d:%02d.%03d" % (lt.tm_hour, lt.tm_min, lt.tm_sec, int(round((t % 1.0 * 1000), 3)))
    logMessage = "%s\t%s" % (timeStr, message)

    print(logMessage)

    if gLogFile != None:
        gLogFile.write(logMessage)
        gLogFile.write("\n")
        gLogFile.flush()
    return

def ReadImageFromFile(path: str) -> np.ndarray:
    Log("Reading image from file: %s" % path)
    image = Image.open(path).convert("RGBA")
    image = np.array(image, dtype=np.uint8)
    return image

def ReadImageFromMemory(data: bytes) -> np.ndarray:
    Log("Reading image from memory...")
    image = Image.open(io.BytesIO(data)).convert("RGBA")
    image = np.array(image, dtype=np.uint8)
    return image

def SaveImageToFile(path: str, image: np.ndarray) -> None:
    Log("Saving image to file: %s" % path)
    image = Image.fromarray(image)
    image.save(path)
    image.close()
    return

def DeleteImageFile(path: str) -> None:
    Log("Trying to delete image file: %s" % path)
    try:
        os.remove(path)
    except:
        pass
    return

def MakeUniqueName(pattern: str, isUnique) -> str:
    MAX_COLLISIONS = 500
    MAX_NUMBER = 99999
    for trial in range(MAX_COLLISIONS):
        number = random.randint(0, MAX_NUMBER)
        result = pattern % number
        if isUnique(result):
            return result
    raise Exception("MakeUniqueName Failed")
    return None

def IsNdArrayValid(array: np.ndarray) -> bool:
    return type(array) == np.ndarray

def PixelsSpiltAlpha(pixels: np.ndarray):
    pixels = pixels.transpose([2, 0, 1])
    rgb = pixels[0:3].transpose([1, 2, 0])
    a = pixels[3]
    return rgb, a

def PixelsMergeAlpha(rgb: np.ndarray, a: np.ndarray):
    rgb = rgb.transpose([2, 0, 1])
    a = np.expand_dims(a, axis=0)
    pixels = np.vstack([rgb, a])
    pixels = pixels.transpose([1, 2, 0])
    return pixels

# End - Helpers
# ----------------------------------------------



# ----------------------------------------------
# Begin - MetaClasses

class MetaValue():
    TypeBool = "Bool"
    TypeColor = "Color"
    TypeString = "String"
    TypeFloat = "Float"
    TypeInt = "Int"
    TypeVector = "Vector"
    TypeUnknown = "Unknown"

    def __init__(self, type: str = None, value: Any = None):
        if type == None:
            self.Type = MetaValue.TypeUnknown
        else:
            self.Type = type
        self.Value = value
        return

    def HasValue(self) -> bool:
        return self.Value != None

    def AsRGBAColor(self, default_value=None) -> np.ndarray:
        if self.Value == None:
            return default_value
        try:
            color = [self.Value[0], self.Value[1], self.Value[2], self.Value[3]]
            return (np.array(color) * 255.0).astype(np.uint8)
        except:
            return default_value

    def AsFloat(self, default_value=None) -> float:
        if self.Value == None:
            return default_value
        try:
            return float(self.Value)
        except:
            return default_value

    def AsD5Color(self, default_value=None) -> D5Color:
        rgbaColor = self.AsRGBAColor()
        if type(rgbaColor) == np.ndarray:
            return D5Color(rgbaColor[0], rgbaColor[1], rgbaColor[2])
        else:
            return default_value

class MetaTexture():
    def __init__(self):
        self.Pixels: np.ndarray = None
        self.NeedsBake: bool = False
        self.OutSocketToBake: bpy.types.NodeSocket = None

        self.Brightness: float = None
        self.IsInverted: bool = None
        self.Width: float = None
        self.Height: float = None
        self.U_Offset: float = None
        self.V_Offset: float = None
        self.Rotation: float = None

        return

    def getFileName(self, mtlName: str, texKind: str) -> str:
        baseName = "%s_%s" % (mtlName, texKind)
        def texNotExist(x): return not os.path.exists(
            os.path.join(gTextureDir, x))
        if texNotExist(baseName + gIamgeFormat):
            fileName = baseName + gIamgeFormat
        else:
            fileName = MakeUniqueName(
                baseName + "_%s" + gIamgeFormat, texNotExist)
        return fileName

    def ToD5Texture(self, mtlName: str, texKind: str) -> D5Texture:
        Log("Converting MetaTexture to D5Texture")
        Log("\tMtlName: %s, TexKind: %s, NeedsBake: %s, HasPixels: %s" % (mtlName, texKind, self.NeedsBake, IsNdArrayValid(self.Pixels)))

        if self.NeedsBake:
            return None
        if not IsNdArrayValid(self.Pixels):
            return None

        imageName = self.getFileName(mtlName, texKind)
        imagePath = os.path.join(gTextureDir, imageName)

        SaveImageToFile(imagePath, self.Pixels)

        d5Texture = D5Texture()
        d5Texture.FilePath = imageName
        d5Texture.Brightness = self.Brightness
        d5Texture.IsInverted: bool = self.IsInverted
        d5Texture.Width: float = self.Width
        d5Texture.Height: float = self.Height
        d5Texture.U_Offset: float = self.U_Offset
        d5Texture.V_Offset: float = self.V_Offset
        d5Texture.Rotation: float = self.Rotation

        return d5Texture

class MetaMaterial():
    def __init__(self):
        self.NeedsBake = False

        self.Textures: Dict[str, MetaTexture] = dict()
        for texKind in D5TextureKind.D5TextureAll:
            self.Textures[texKind] = None

        self.Opacity: float = None
        self.DiffuseColor: D5Color = None
        self.EmissiveColor: D5Color = None
        self.EmissiveStrength: float = None  # 0.0-10.0
        self.TintColor: D5Color = None
        self.Roughness: float = None
        self.BumpAmount: int = None
        self.Metallic: float = None
        self.Specular: float = None
        self.IndexOfRefraction: float = None  # 0.0-3.0
        pass

    def Normalize(self) -> None:
        needsBake = False
        for texture in self.Textures.values():
            if texture != None and texture.NeedsBake:
                needsBake = True
        if needsBake == True:
            for texture in self.Textures.values():
                if texture != None:
                    texture.NeedsBake = True
                    texture.Pixels = None
        self.NeedsBake = needsBake
        return

    def ToD5Material(self, mtlName: str) -> D5Material:
        self.Normalize()
        Log("Converting MetaMaterial to D5Material")
        Log("\tMtlName: %s, NeedsBake: %s" % (mtlName, self.NeedsBake))

        if self.NeedsBake:
            return None

        d5Material = D5Material()

        d5Material.Name = mtlName
        d5Material.Opacity = self.Opacity
        d5Material.DiffuseColor = self.DiffuseColor
        d5Material.EmissiveColor = self.EmissiveColor
        d5Material.EmissiveStrength = self.EmissiveStrength
        d5Material.TintColor = self.TintColor
        d5Material.Roughness = self.Roughness
        d5Material.BumpAmount = self.BumpAmount
        d5Material.Metallic = self.Metallic
        d5Material.Specular = self.Specular
        d5Material.IndexOfRefraction = self.IndexOfRefraction

        for texKind in self.Textures:
            if self.Textures[texKind] != None:
                d5Texture = self.Textures[texKind].ToD5Texture(
                    mtlName, texKind)
                if d5Texture != None:
                    d5Material.Textures[texKind] = d5Texture
        return d5Material

# Return: (FromNode, FromSocketId)

def FindInput(toNode: bpy.types.ShaderNode, toSocketId: str, fromSocketId: str = None) -> Tuple[bpy.types.ShaderNode, str]:
    if gCurrentMaterial == None:
        return (None, None)
    if not gCurrentMaterial.use_nodes:
        return (None, None)

    for link in gCurrentMaterial.node_tree.links:
        if link.to_node == toNode and link.to_socket.identifier == toSocketId:
            if fromSocketId == None or link.from_socket.identifier == fromSocketId:
                # Workaround for Groups
                if type(link.from_node) == bpy.types.ShaderNodeGroup:
                    return (link.from_node, link.from_socket.name)
                else:
                    return (link.from_node, link.from_socket.identifier)

    return (None, None)

def FetchValue(toNode: bpy.types.ShaderNode, toSocketId: str, fromSocketId: str = None) -> MetaValue:
    def FetchDefaultValue(inputSocket: bpy.types.NodeSocket) -> MetaValue:
        metaValue = MetaValue()
        if type(inputSocket) == bpy.types.NodeSocketBool:
            metaValue.Type == MetaValue.TypeBool
        elif type(inputSocket) == bpy.types.NodeSocketColor:
            metaValue.Type == MetaValue.TypeColor
        elif type(inputSocket) == bpy.types.NodeSocketString:
            metaValue.Type == MetaValue.TypeString
        elif type(inputSocket) == [bpy.types.NodeSocketFloat, bpy.types.NodeSocketFloatAngle, bpy.types.NodeSocketFloatFactor, bpy.types.NodeSocketFloatPercentage, bpy.types.NodeSocketFloatTime, bpy.types.NodeSocketFloatUnsigned]:
            metaValue.Type == MetaValue.TypeFloat
        elif type(inputSocket) in [bpy.types.NodeSocketInt, bpy.types.NodeSocketIntFactor, bpy.types.NodeSocketIntPercentage, bpy.types.NodeSocketIntUnsigned]:
            metaValue.Type == MetaValue.TypeInt
        elif type(inputSocket) in [bpy.types.NodeSocketVector, bpy.types.NodeSocketVectorAcceleration, bpy.types.NodeSocketVectorDirection, bpy.types.NodeSocketVectorEuler, bpy.types.NodeSocketVectorTranslation, bpy.types.NodeSocketVectorVelocity, bpy.types.NodeSocketVectorXYZ]:
            metaValue.Type == MetaValue.TypeVector
        else:
            metaValue.Type == MetaValue.TypeUnknown

        if hasattr(inputSocket, "default_value"):
            metaValue.Value = inputSocket.default_value

        return metaValue

    fromNode, fromSocketId = FindInput(toNode, toSocketId, fromSocketId)

    if fromNode == None:
        return FetchDefaultValue(toNode.inputs[toSocketId])
    if fromNode.type in gValueMappers.keys():
        return gValueMappers[fromNode.type](fromNode, fromSocketId)
    else:
        if fromNode.type not in gMaterialMappers.keys() and fromNode.type not in gTextureMappers.keys():
            Log("Invalid node type for value: %s" % fromNode.type)
        return FetchDefaultValue(toNode.inputs[toSocketId])

def FetchTexture(toNode: bpy.types.ShaderNode, toSocketId: str, fromSocketId: str = None) -> MetaTexture:
    fromNode, fromSocketId = FindInput(toNode, toSocketId, fromSocketId)

    if fromNode == None:
        return None
    if fromNode.type in gTextureMappers.keys():
        return gTextureMappers[fromNode.type](fromNode, fromSocketId)
    else:
        Log("Invalid node type for texture: %s" % fromNode.type)
        return None

def FetchMaterial(toNode: bpy.types.ShaderNode, toSocketId: str, fromSocketId: str = None) -> MetaMaterial:
    fromNode, fromSocketId = FindInput(toNode, toSocketId, fromSocketId)

    if fromNode == None:
        return None
    if fromNode.type in gMaterialMappers.keys():
        return gMaterialMappers[fromNode.type](fromNode, fromSocketId)
    else:
        Log("Invalid node type for material: %s" % fromNode.type)
        return None

def MapMaterial(mtl: bpy.types.Material) -> MetaMaterial:
    if mtl is None:
        return None

    Log("Mapping Material: %s, Use nodes: %s" % (mtl.name, mtl.use_nodes))

    global gCurrentMaterial
    gCurrentMaterial = mtl

    metaMaterial = None
    if gCurrentMaterial.use_nodes:
        outputNode = gCurrentMaterial.node_tree.get_output_node("ALL")

        if outputNode:
            if outputNode.type not in gMaterialMappers.keys():
                Log("Invalid output node type: %s" % outputNode.type)
            else:
                metaMaterial = gMaterialMappers[outputNode.type](
                    outputNode, None)
                if metaMaterial is not None:
                    metaMaterial.Normalize()
                    return metaMaterial

    if metaMaterial is None:
        metaMaterial = MetaMaterial()
        metaMaterial.DiffuseColor = D5Color.FromFloatArray(
            gCurrentMaterial.diffuse_color)
        metaMaterial.Roughness = gCurrentMaterial.roughness
        metaMaterial.Specular = gCurrentMaterial.specular_intensity
        metaMaterial.Metallic = gCurrentMaterial.metallic

    gCurrentMaterial = None

    return metaMaterial

# End - MetaClasses
# ----------------------------------------------



# ----------------------------------------------
# Begin - SharedNodeProcessors

# Shaders

def ReadColorAndTexture(node: bpy.types.ShaderNode, inputSocketId: str) -> [D5Color, MetaTexture]:
    color = FetchValue(node, inputSocketId).AsD5Color()
    texture = FetchTexture(node, inputSocketId)
    return color, texture

def ReadFloatAndTexture(node: bpy.types.ShaderNode, inputSocketId: str) -> [float, MetaTexture]:
    floatValue = FetchValue(node, inputSocketId).AsFloat()
    texture = FetchTexture(node, inputSocketId)
    return floatValue, texture

def ReadNormal(node: bpy.types.ShaderNode, inputSocketId: str) -> [float, MetaTexture]:
    normalNode, normalOutSocketId = FindInput(node, inputSocketId)
    normalTexture = FetchTexture(node, "Normal")
    try:
        if normalNode and normalOutSocketId == "Normal":
            normalStrength = FetchValue(normalNode, "Strength").AsFloat()
            if normalStrength != None:
                bumpAmount = min(normalStrength, 10.0)
                return bumpAmount, normalTexture
    except:
        pass
    return None, normalTexture

def BsdfShared(node: bpy.types.ShaderNode) -> MetaMaterial:
    metaMaterial = MetaMaterial()

    # Base Color
    diffuseColor, diffuseTexture = ReadColorAndTexture(node, "Color")
    metaMaterial.DiffuseColor = diffuseColor
    metaMaterial.Textures[D5TextureKind.D5TextureDiffuse] = diffuseTexture

    # Normal
    bumpAmount, normalTexture = ReadNormal(node, "Normal")
    metaMaterial.BumpAmount = bumpAmount
    metaMaterial.Textures[D5TextureKind.D5TextureBump] = normalTexture

    # Roughness
    roughnessValue, roughnessTexture = ReadFloatAndTexture(node, "Roughness")
    metaMaterial.Roughness = roughnessValue
    metaMaterial.Textures[D5TextureKind.D5TextureRoughness] = roughnessTexture
    if roughnessTexture != None:
        metaMaterial.Textures[D5TextureKind.D5TextureRoughness].Brightness = metaMaterial.Roughness

    return metaMaterial

# Textures

def MixTexturesWithColors(leftTex: MetaTexture, rightTex: MetaTexture, leftColor: np.ndarray, rightColor: np.ndarray, fac: float, outSocket: bpy.types.NodeSocket) -> MetaTexture:
    def MakeColorTex(color: np.ndarray) -> np.ndarray:
        pixel = color.reshape([1, 4])
        pixels = np.repeat(pixel, goTextureSize * goTextureSize,
                           axis=0).reshape([goTextureSize, goTextureSize, -1])
        return pixels

    def MixTwoImages(left: np.ndarray, right: np.ndarray, fac: float) -> np.ndarray:
        left = Image.fromarray(left).convert("RGBA").resize(
            (goTextureSize, goTextureSize), resample=Image.BICUBIC)
        right = Image.fromarray(right).convert("RGBA").resize(
            (goTextureSize, goTextureSize), resample=Image.BICUBIC)
        left = np.array(left)
        right = np.array(right)
        return (left * (1.0 - fac) + right * fac).astype(np.uint8)

    def MixImageWithColor(image: np.ndarray, color: np.ndarray, fac: float) -> np.ndarray:
        if fac == 0.0:
            return image
        elif fac == 1.0:
            return MakeColorTex(color)
        else:
            return (image * (1.0 - fac) + color * fac).astype(np.uint8)

    # If needs to bake
    if (leftTex != None and leftTex.NeedsBake) or (rightTex != None and rightTex.NeedsBake):
        if leftTex != None:
            leftTex.OutSocketToBake = outSocket
            return leftTex
        else:
            rightTex.OutSocketToBake = outSocket
            return rightTex

    # Otherwise, mix pixels
    leftHasPixels = leftTex != None and IsNdArrayValid(leftTex.Pixels)
    rightHasPixels = rightTex != None and IsNdArrayValid(rightTex.Pixels)
    leftHasColor = IsNdArrayValid(leftColor)
    rightHasColor = IsNdArrayValid(rightColor)

    if fac == None:
        metaTexture = MetaTexture()
        metaTexture.NeedsBake = True
        metaTexture.OutSocketToBake = outSocket
        return metaTexture

    mixedPixels = None
    if not leftHasPixels and not rightHasPixels:
        mixedColor = None
        if not leftHasColor and not rightHasColor:
            mixedColor = (leftColor * (1 - fac) +
                          rightColor * fac).astype(np.uint8)
        elif leftHasColor:
            mixedColor = leftColor
        elif rightHasColor:
            mixedColor = rightColor
        if IsNdArrayValid(mixedColor):
            mixedPixels = MakeColorTex(mixedColor)
    elif leftHasPixels and rightHasPixels:
        mixedPixels = MixTwoImages(leftTex.Pixels, rightTex.Pixels, fac)
    elif leftHasPixels:
        if rightHasColor:
            mixedPixels = MixImageWithColor(leftTex.Pixels, rightColor, fac)
        else:
            mixedPixels = leftTex.Pixels
    elif rightHasPixels:
        if leftHasColor:
            mixedPixels = MixImageWithColor(
                rightTex.Pixels, leftColor, 1.0-fac)
        else:
            mixedPixels = rightTex.Pixels

    if not IsNdArrayValid(mixedPixels):
        return None

    # Resolve UV
    if leftHasPixels:
        metaTexture = leftTex
    elif rightHasPixels:
        metaTexture = rightTex
    else:
        metaTexture = MetaTexture()
    metaTexture.Pixels = mixedPixels
    metaTexture.OutSocketToBake = outSocket
    return metaTexture

def PassThorghTexture(node: bpy.types.ShaderNode, outSocketId: str, inputSocketId: str) -> MetaTexture:
    originalTex = FetchTexture(node, inputSocketId)

    if originalTex == None:
        return None
    if originalTex.NeedsBake:
        originalTex.OutSocketToBake = node.outputs[outSocketId]

    return originalTex

# End - SharedNodeProcessors
# ----------------------------------------------



# ----------------------------------------------
# Begin - MaterialMappers

# Inputs

def TextureCoordinate(node: bpy.types.ShaderNodeTexCoord, outSocketId: str) -> MetaTexture:
    metaTexture = MetaTexture()
    metaTexture.OutSocketToBake = node.outputs[outSocketId]
    if outSocketId == "Object":
        metaTexture.NeedsBake = True
    return metaTexture

def NewGeometry(node: bpy.types.ShaderNodeNewGeometry, outSocketId: str) -> MetaTexture:
    metaTexture = MetaTexture()
    metaTexture.OutSocketToBake = node.outputs[outSocketId]
    metaTexture.NeedsBake = True
    return metaTexture


# Outputs

def OutputMaterial(node: bpy.types.ShaderNodeOutputMaterial, outSocketId: str) -> MetaMaterial:
    return FetchMaterial(node, "Surface")

# Shaders

def MixShader(node: bpy.types.ShaderNodeMixShader, outSocketId: str) -> MetaMaterial:
    # Get Inputs
    facTexture = FetchTexture(node, "Fac")
    fac = FetchValue(node, "Fac").AsFloat()
    leftMaterial = FetchMaterial(node, "Shader")
    leftNode, _ = FindInput(node, "Shader")
    rightMaterial = FetchMaterial(node, "Shader.001")
    rightNode, _ = FindInput(node, "Shader.001")
    if rightMaterial is None: # Different Versions of MixShader has Different Identifiers
        rightMaterial = FetchMaterial(node, "Shader_001")
        rightNode, _ = FindInput(node, "Shader_001")

    if not leftMaterial and not rightMaterial:
        return None
    if not leftMaterial:
        return rightMaterial
    if not rightMaterial:
        return leftMaterial

    if facTexture != None:
        # For transparent
        if rightNode.type == "BSDF_TRANSPARENT":
            leftMaterial.Textures[D5TextureKind.D5TextureMask] = facTexture
            return leftMaterial
        if leftNode.type == "BSDF_TRANSPARENT":
            rightMaterial.Textures[D5TextureKind.D5TextureMask] = facTexture
            return rightMaterial
        # For Emission
        # We do not support emission map
        if rightNode.type == "EMISSION":
            return leftMaterial
        if leftNode.type == "EMISSION":
            return rightMaterial

    if fac == None or fac == 1.0:
        return rightMaterial
    if fac == 0.0:
        return leftMaterial

    # Helper for mix
    def HasNone(left: Any, right: Any) -> Tuple[bool, Any]:
        if left == None and right == None:
            return True, None
        if left == None:
            return True, right
        if right == None:
            return True, left
        return False, None

    def MixFloats(leftValue: float, rightValue: float, fac: float):
        hasNone, result = HasNone(leftValue, rightValue)
        if hasNone:
            return result
        return (1.0 - fac) * leftValue + fac * rightValue

    def MixColors(leftColor: D5Color, rightColor: D5Color, fac: float):
        hasNone, result = HasNone(leftColor, rightColor)
        if hasNone:
            return result
        return D5Color.FromFloatArray((1.0 - fac) * np.array(leftColor.ToFloatArray()) + fac * np.array(rightColor.ToFloatArray()))

    def MixTextures(leftTexure: MetaTexture, rightTexture: MetaTexture, fac: float):
        hasNone, result = HasNone(leftTexure, rightTexture)
        if hasNone:
            return result
        # TODO: Mix Textures
        return leftTexure

    # We have to mix them
    mixedMaterial = MetaMaterial()

    mixedMaterial.DiffuseColor = MixColors(
        leftMaterial.DiffuseColor, rightMaterial.DiffuseColor, fac)
    mixedMaterial.EmissiveColor = MixColors(
        leftMaterial.EmissiveColor, rightMaterial.EmissiveColor, fac)
    mixedMaterial.TintColor = MixColors(
        leftMaterial.TintColor, rightMaterial.TintColor, fac)

    mixedMaterial.Opacity = MixFloats(
        leftMaterial.Opacity, rightMaterial.Opacity, fac)
    mixedMaterial.EmissiveStrength = MixFloats(
        leftMaterial.EmissiveStrength, rightMaterial.EmissiveStrength, fac)

    mixedMaterial.Roughness = MixFloats(
        leftMaterial.Roughness, rightMaterial.Roughness, fac)
    mixedMaterial.BumpAmount = MixFloats(
        leftMaterial.BumpAmount, rightMaterial.BumpAmount, fac)
    mixedMaterial.Metallic = MixFloats(
        leftMaterial.Metallic, rightMaterial.Metallic, fac)
    mixedMaterial.Specular = MixFloats(
        leftMaterial.Specular, rightMaterial.Specular, fac)
    mixedMaterial.IndexOfRefraction = MixFloats(
        leftMaterial.IndexOfRefraction, rightMaterial.IndexOfRefraction, fac)

    for texKind in D5TextureKind.D5TextureAll:
        mixedMaterial.Textures[texKind] = MixTextures(
            leftMaterial.Textures[texKind], rightMaterial.Textures[texKind], fac)

    return mixedMaterial

def BsdfPrincipled(node: bpy.types.ShaderNodeBsdfPrincipled, outSocketId: str) -> MetaMaterial:
    metaMaterial = MetaMaterial()

    # Base Color
    diffuseColor, diffuseTexture = ReadColorAndTexture(node, "Base Color")
    metaMaterial.DiffuseColor = diffuseColor
    metaMaterial.Textures[D5TextureKind.D5TextureDiffuse] = diffuseTexture

    # Normal
    bumpAmount, normalTexture = ReadNormal(node, "Normal")
    metaMaterial.BumpAmount = bumpAmount
    metaMaterial.Textures[D5TextureKind.D5TextureBump] = normalTexture

    # Specular
    specularValue, specularTexture = ReadFloatAndTexture(node, "Specular")
    metaMaterial.Specular = specularValue
    metaMaterial.Textures[D5TextureKind.D5TextureSpecular] = specularTexture

    # Roughness
    roughnessValue, roughnessTexture = ReadFloatAndTexture(node, "Roughness")
    metaMaterial.Roughness = roughnessValue
    metaMaterial.Textures[D5TextureKind.D5TextureRoughness] = roughnessTexture
    if roughnessTexture != None:
        metaMaterial.Textures[D5TextureKind.D5TextureRoughness].Brightness = metaMaterial.Roughness

    # Opacity
    opcacityValue, opacityTexture = ReadFloatAndTexture(node, "Alpha")
    metaMaterial.Opacity = opcacityValue
    metaMaterial.Textures[D5TextureKind.D5TextureMask] = opacityTexture

    # Metallic
    metallicValue, metallicTexture = ReadFloatAndTexture(node, "Metallic")
    metaMaterial.Metallic = metallicValue
    metaMaterial.Textures[D5TextureKind.D5TextureMetal] = metallicTexture

    # Emission
    emissiveColor = FetchValue(node, "Emission").AsD5Color()
    if emissiveColor != None:
        metaMaterial.EmissiveColor = emissiveColor
        metaMaterial.EmissiveStrength = np.average(
            emissiveColor.ToFloatArray())

    # IOR
    iorValue = FetchValue(node, "IOR").AsFloat()
    if iorValue != None:
        metaMaterial.IndexOfRefraction = min(iorValue, 3.0)

    return metaMaterial

def BsdfDiffuse(node: bpy.types.ShaderNodeBsdfDiffuse, outSocketId: str) -> MetaMaterial:
    metaMaterial = BsdfShared(node)

    # BsdfDiffuse Specific
    metaMaterial.Specular = 0.0
    metaMaterial.Metallic = 0.0

    metaMaterial.Roughness = 1.0

    return metaMaterial

def BsdfGalss(node: bpy.types.ShaderNodeBsdfGlass, outSockedId: str) -> MetaMaterial:
    metaMaterial = BsdfShared(node)

    metaMaterial.Opacity = 0.5

    return metaMaterial

def BsdfGlossy(node: bpy.types.ShaderNodeBsdfGlossy, outSocketId: str) -> MetaMaterial:
    metaMaterial = BsdfShared(node)
    # BsdfDiffuse Specific
    metaMaterial.Specular = 0.0
    metaMaterial.Metallic = 1.0

    return metaMaterial

def BsdfTransparent(node: bpy.types.ShaderNodeBsdfTransparent, outSocketId: str) -> MetaMaterial:
    metaMaterial = MetaMaterial()

    color, texture = ReadColorAndTexture(node, "Color")
    metaMaterial.DiffuseColor = color
    metaMaterial.Textures[D5TextureKind.D5TextureDiffuse] = texture

    metaMaterial.Opacity = 1.0 - np.average(color.ToFloatArray())

    return metaMaterial

def Emission(node: bpy.types.ShaderNodeEmission, outSocketId: str) -> MetaMaterial:
    metaMaterial = MetaMaterial()

    color = FetchValue(node, "Color").AsD5Color()
    strength = FetchValue(node, "Strength").AsFloat()
    if strength == None and color != None:
        strength = 1.0 - np.average(color.ToFloatArray())

    metaMaterial.EmissiveColor = color
    metaMaterial.EmissiveStrength = strength

    return metaMaterial

# Others

def RerouteMaterial(node: bpy.types.ShaderNode, outSocketId: str) -> MetaMaterial:
    return FetchMaterial(node, "Input")

# End - MaterialMappers
# ----------------------------------------------



# ----------------------------------------------
# Begin - TextureMappers

# Colors

def BrightContrast(node: bpy.types.ShaderNodeBrightContrast, outSocketId: str) -> MetaTexture:
    def BrightInternal(image: np.ndarray, fac: float):
        if fac < 0:
            fac = (fac * 255.0)
        if fac > 0:
            fac = math.pow((fac / 100.0), 0.1) * 255.0
            
        return (image.astype(np.float) + fac).clip(0, 255).astype(np.uint8)

    def ContrastInternal(image: np.ndarray, fac: float):
        return ((image.astype(np.float) - 128) * (fac + 1.0) + 128).clip(0, 255).astype(np.uint8)

    if outSocketId != "Color":
        return None
    originalTex = FetchTexture(node, "Color")
    if originalTex == None:
        return None
    originalTex.OutSocketToBake = node.outputs[outSocketId]

    if IsNdArrayValid(originalTex.Pixels):
        bright = FetchValue(node, "Bright").AsFloat()
        contrast = node.inputs["Contrast"].default_value
        rgb, a = PixelsSpiltAlpha(originalTex.Pixels)
        rgb = BrightInternal(rgb, bright)
        rgb = ContrastInternal(rgb, contrast)
        originalTex.Pixels = PixelsMergeAlpha(rgb, a)

    return originalTex

def Gamma(node: bpy.types.ShaderNodeGamma, outSocketId: str) -> MetaTexture:
    def GammaInternal(image: np.ndarray, gamma: float):
        lut = np.zeros([256], dtype=np.float)
        for x in range(256):
            lut[x] = int(math.pow(float(x) / 255.0, gamma) * 255.0)
        image = image.transpose([2, 0, 1])
        for c in range(3):
            image[c] = lut[image[c]]
        image = image.transpose([1, 2, 0])
        return image

    if outSocketId != "Color":
        return None
    originalTex = FetchTexture(node, "Color")
    if originalTex == None:
        return None
    originalTex.OutSocketToBake = node.outputs[outSocketId]

    if IsNdArrayValid(originalTex.Pixels):
        gamma = node.inputs["Gamma"].default_value
        
        rgb, a = PixelsSpiltAlpha(originalTex.Pixels)
        rgb = GammaInternal(rgb, gamma)
        originalTex.Pixels = PixelsMergeAlpha(rgb, a)

    return originalTex

def HueSat(node: bpy.types.ShaderNodeHueSaturation, outSocketId: str) -> MetaTexture:
    def HueSatInternal(image: np.ndarray, h: float, s: float, v: float):
        image = Image.fromarray(image).convert("HSV")
        image = np.array(image, dtype=np.float) / 255.0
        image = image.transpose([2, 0, 1])
        image[0] = (image[0] + ((h * 2) - 1.0)) % 1.0
        image[1] = (image[1] * s).clip(max=1.0)
        image[2] = (image[2] * v).clip(max=1.0)
        image = image * 255.0
        image = image.astype(np.uint8)
        image = image.transpose([1, 2, 0])
        image = Image.fromarray(image, mode="HSV").convert("RGB")
        image = np.array(image, dtype=np.uint8)
        return image

    if outSocketId != "Color":
        return None
    originalTex = FetchTexture(node, "Color")
    if originalTex == None:
        return None
    originalTex.OutSocketToBake = node.outputs[outSocketId]

    if IsNdArrayValid(originalTex.Pixels):
        # TODO: Research how Fac affects others parameters
        fac = node.inputs["Fac"].default_value
        hue = (node.inputs["Hue"].default_value - 0.5) * fac + 0.5
        sat = math.pow(node.inputs["Saturation"].default_value, fac)
        val = math.pow(node.inputs["Value"].default_value, fac)
        rgb, a = PixelsSpiltAlpha(originalTex.Pixels)
        rgb = HueSatInternal(rgb, hue, sat, val)
        originalTex.Pixels = PixelsMergeAlpha(rgb, a)

    return originalTex

def Invert(node: bpy.types.ShaderNodeInvert, outSocketId: str) -> MetaTexture:
    def InvertInternal(image: np.ndarray, fac: float):
        if fac == 0.0:
            return image
        originalImage = image
        originalAlpha = None
        if image.shape[2] == 4:
            image = image.transpose([2, 0, 1])
            originalAlpha = image[3]
        image = np.bitwise_not(image)
        if originalAlpha:
            image[3] = originalAlpha
            image = image.transpose([1, 2, 0])
        if fac == 1.0:
            return image

        return (fac * image + (1.0 - fac) * originalImage).astype(np.uint8)

    if outSocketId != "Color":
        return None
    originalTex = FetchTexture(node, "Color")
    if originalTex == None:
        return None
    originalTex.OutSocketToBake = node.outputs[outSocketId]

    if IsNdArrayValid(originalTex.Pixels):
        fac = node.inputs["Fac"].default_value

        rgb, a = PixelsSpiltAlpha(originalTex.Pixels)
        rgb = InvertInternal(rgb, fac)
        originalTex.Pixels = PixelsMergeAlpha(rgb, a) 

    return originalTex

def MixRGB(node: bpy.types.ShaderNodeMixRGB, outSocketId: str) -> MetaTexture:
    # TODO: Resolve Mix Mode

    if outSocketId != "Color":
        return None

    # Get inputs
    facTex = FetchTexture(node, "Fac")
    if facTex != None:
        facTex.OutSocketToBake = node.outputs[outSocketId]
        facTex.NeedsBake = True
        return facTex

    fac = FetchValue(node, "Fac").AsFloat()
    leftTex = FetchTexture(node, "Color1")
    rightTex = FetchTexture(node, "Color2")
    leftColor = FetchValue(node, "Color1").AsRGBAColor()
    rightColor = FetchValue(node, "Color2").AsRGBAColor()
    

    outSocket = node.outputs[outSocketId]

    return MixTexturesWithColors(leftTex, rightTex, leftColor, rightColor, fac, outSocket)

def RGBCurve(node: bpy.types.ShaderNodeRGBCurve, outSocketId: str) -> MetaTexture:
    Log("RGBCurve is not implemented.")
    return PassThorghTexture(node, outSocketId, "Color")

# Textures


def ImageTexture(node: bpy.types.ShaderNodeTexImage, outSocketId: str) -> MetaTexture:
    if node.image == None:
        Log("No image in node: %s" % node.name)
        return None

    # Might be 'Alpha', whatever
    # if outSocketId != "Color":
    #     return None

    metaTexture = FetchTexture(node, "Vector")
    if metaTexture == None:
        metaTexture = MetaTexture()

    metaTexture.OutSocketToBake = node.outputs[outSocketId]

    image = node.image
    pixels = None

    if not image.has_data:
        try:
            image.update()
        except:
            pass

    if image.has_data:
        # Read from file
        if image.source == "FILE":
            try:
                imagePath = os.path.normpath(image.filepath).lstrip("/\\")
                dirname = os.path.dirname(bpy.data.filepath)
                possiblePaths = list()
                possiblePaths.append(imagePath)
                possiblePaths.append(os.path.join(dirname, imagePath))
                imagePath = imagePath.replace("../", "").replace("..\\", "")
                possiblePaths.append(os.path.join(dirname, imagePath))
                for p in possiblePaths:
                    if os.path.exists(p) and os.path.isfile(p):
                        pixels = ReadImageFromFile(p)
                        break
            except:
                Log("Failed to read image file: %s\nReading from blender image buffer..." % possiblePaths[0])
            if not IsNdArrayValid(pixels):
                try:
                    if image.packed_file and image.packed_file.data:
                        pixels = ReadImageFromMemory(image.packed_file.data)
                except:
                    pass

        if not IsNdArrayValid(pixels):
            try:
                Log("Reading from internal pixels, this might be slow")
                pixels = (np.array(image.pixels) * 255.0).astype(np.uint8)
                pixels = pixels.reshape([image.size[1], image.size[0], -1])
                if pixels.shape[2] == 3:
                    pixels = pixels.transpose([2, 0, 1])
                    alphaShape = [1, pixels.shape[1], pixels.shape[2]]
                    alpha = np.ones(shape=alphaShape, dtype=np.uint8) * 255
                    pixels = np.vstack([pixels, alpha])
                    pixels = pixels.transpose([1, 2, 0])
                pixels = np.flipud(pixels)
            except:
                pass

    if not IsNdArrayValid(pixels):
        return None
    else:
        metaTexture.Pixels = pixels

    return metaTexture

def BuiltInTexture(node: bpy.types.ShaderNode, outSocketId: str) -> MetaTexture:
    metaTexture = MetaTexture()
    metaTexture.NeedsBake = True
    metaTexture.OutSocketToBake = node.outputs[outSocketId]
    return metaTexture

def Bump(node: bpy.types.ShaderNodeBump, outSocketId: str) -> MetaTexture:
    # TODO: NOW
    Log("Bump is not implemented.")
    metaTexture = PassThorghTexture(node, outSocketId, "Height")
    if metaTexture == None:
        PassThorghTexture(node, outSocketId, "Normal")
    if metaTexture != None:
        metaTexture.OutSocketToBake = node.outputs[outSocketId]
    return metaTexture

def NormalMap(node: bpy.types.ShaderNodeNormalMap, outSocketId: str) -> MetaTexture:
    # TODO: NOW
    Log("NormalMap is not fully implemented.")
    metaTexture = PassThorghTexture(node, outSocketId, "Color")
    if metaTexture != None:
        metaTexture.OutSocketToBake = node.outputs[outSocketId]
    return metaTexture

def Mapping(node: bpy.types.ShaderNodeMapping, outSocketId: str) -> MetaTexture:
    metaTexture = FetchTexture(node, "Vector")
    if metaTexture == None:
        metaTexture = MetaTexture()

    metaTexture.OutSocketToBake = node.outputs[outSocketId]

    if metaTexture.NeedsBake:
        return metaTexture

    # UV Offset
    if node.vector_type == "POINT" or node.vector_type == "TEXTURE":
        metaTexture.U_Offset = node.inputs["Location"].default_value[0]
        metaTexture.V_Offset = node.inputs["Location"].default_value[1]
    # Scale
    if node.vector_type == "POINT":
        if node.inputs["Scale"].default_value[0] != 0:
            metaTexture.Width = 1.0 / node.inputs["Scale"].default_value[0]
        if node.inputs["Scale"].default_value[1] != 0:
            metaTexture.Height = 1.0 / node.inputs["Scale"].default_value[1]
    elif node.vector_type == "TEXTURE" or node.vector_type == "VECTOR":
        if node.inputs["Scale"].default_value[0] != 0:
            metaTexture.Width = node.inputs["Scale"].default_value[0]
        if node.inputs["Scale"].default_value[1] != 0:
            metaTexture.Height = node.inputs["Scale"].default_value[1]
    # Rotation
    metaTexture.Rotation = node.inputs["Rotation"].default_value[2]

    return metaTexture

# Converters

def Clamp(node: bpy.types.ShaderNodeClamp, outSocketId: str) -> MetaTexture:
    # TODO: NOW
    Log("Clamp is not implemented.")
    metaTexture = PassThorghTexture(node, outSocketId, "Value")
    if metaTexture != None:
        metaTexture.OutSocketToBake = node.outputs[outSocketId]
    return metaTexture

def ColorRamp(node: bpy.types.ShaderNode, outSocketId: str) -> MetaTexture:
    # TODO: NOW
    Log("ClolorRamp is not implemented.")
    metaTexture = PassThorghTexture(node, outSocketId, "Fac")
    if metaTexture != None:
        metaTexture.OutSocketToBake = node.outputs[outSocketId]
    return metaTexture

def SeperateShared(node: bpy.types.ShaderNode, outSocketId: str, names: str) -> MetaTexture:
    metaTexture = FetchTexture(node, "Image")
    if metaTexture == None:
        return None
    metaTexture.OutSocketToBake = node.outputs[outSocketId]
    if metaTexture.NeedsBake:
        return metaTexture

    if not IsNdArrayValid(metaTexture.Pixels):
        metaTexture.NeedsBake = True
        return metaTexture

    rgb, a = PixelsSpiltAlpha(metaTexture.Pixels)
    if outSocketId[0] == names[0]:
        channelId = 0
    elif outSocketId[0] == names[1]:
        channelId = 1
    elif outSocketId[0] == names[2]:
        channelId = 2
    else:
        return None

    transposed = np.transpose(rgb, [2, 0, 1])
    rgb = np.array([transposed[channelId], transposed[channelId], transposed[channelId]], dtype=np.uint8)
    rgb = np.transpose(rgb, [1, 2, 0])

    metaTexture.Pixels = PixelsMergeAlpha(rgb, a)
    return metaTexture

def CombineShared(node: bpy.types.ShaderNode, outSocketId: str, names: str) -> MetaTexture:
    def MakeChannel(tex, value, shape):
        if tex != None and IsNdArrayValid(tex.Pixels):
            pixels = tex.Pixels
            if pixels.shape != shape:
                pixels = Image.fromarray(pixels).convert("RGB")
                pixels = pixels.resize(shape, resample=Image.BICUBIC)
                pixels = np.array(pixels, dtype=np.uint8)
            pixels = np.transpose(pixels, [2, 0, 1])
            return pixels[0]
        else:
            pixels = np.ones(shape=shape, dtype=np.uint8)
            pixels = int(value * 255.0) * pixels
            return pixels

    rValue, rTex = ReadFloatAndTexture(node, str(names[0]))
    gValue, gTex = ReadFloatAndTexture(node, str(names[1]))
    bValue, bTex = ReadFloatAndTexture(node, str(names[2]))

    metaTexture = None
    for tex in [rTex, gTex, bTex]:
        if tex != None and metaTexture == None:
            metaTexture = tex
        if tex != None and tex.NeedsBake:
            tex.OutSocketToBake = node.outputs[outSocketId]
            return tex
    
    if metaTexture == None:
        metaTexture = MetaTexture()
    metaTexture.OutSocketToBake = node.outputs[outSocketId]

    if IsNdArrayValid(metaTexture.Pixels):
        shape = metaTexture.Pixels.shape[:2]
    else:
        shape = (goTextureSize, goTextureSize)

    newPixels = [
        MakeChannel(rTex, rValue, shape),
        MakeChannel(gTex, gValue, shape),
        MakeChannel(bTex, bValue, shape),
        MakeChannel(None, 1.0, shape)
    ]
    # print(newPixels[0].shape)

    newPixels = np.array(newPixels, dtype=np.uint8)
    newPixels = np.transpose(newPixels, [1, 2, 0])

    metaTexture.Pixels = newPixels

    return metaTexture

def SeperateRGB(node: bpy.types.ShaderNodeCombineRGB, outSocketId: str) -> MetaTexture:
    return SeperateShared(node, outSocketId, "RGB")

def CombineRGB(node: bpy.types.ShaderNodeCombineRGB, outSocketId: str) -> MetaTexture:
    return CombineShared(node, outSocketId, "RGB")

def SeperateXYZ(node: bpy.types.ShaderNodeCombineXYZ, outSocketId: str) -> MetaTexture:
    return SeperateShared(node, outSocketId, "XYZ")

def CombineXYZ(node: bpy.types.ShaderNodeCombineXYZ, outSocketId: str) -> MetaTexture:
    return CombineShared(node, outSocketId, "XYZ")

# Others

def RerouteTexture(node: bpy.types.ShaderNode, outSocketId: str) -> MetaTexture:
    return FetchTexture(node, "Input")

# Groups

# def GroupMaterial(node: bpy.types.ShaderNode) -> D5Material:
#     # TODO: NOW
#     Log("Group is not implemented.")
#     return FetchMaterial(FindNode(node, "Fac"))

def GroupTexture(node: bpy.types.ShaderNode, outSocketId: str) -> MetaTexture:
    # BakeGroups

    if goBakeGroupNodes:
        metaTexture = MetaTexture()
        metaTexture.OutSocketToBake = node.outputs[outSocketId]
        metaTexture.NeedsBake = True
        return metaTexture
    else:
        Log("Group discarded.")
        return None


# End - TextureMappers
# ----------------------------------------------



# ----------------------------------------------
# Begin - D5ABuilders

def selectObject(obj: bpy.types.Object) -> None:
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    return

def rotateUVMaps(uvLayers, times) -> None:
    for i in range(times):
        uvLayers[0].active = True
        name = uvLayers[0].name
        uvLayers[0].name = name + "_old"
        clone = uvLayers.new(do_init=True)
        uvLayers.active.name = name
        uvLayers.remove(uvLayers[0])

# -----------------------------------

def RegisterMappers() -> None:
    Log("Registering shader node mappers...")
    # Inputs & Outputs

    gTextureMappers["TEX_COORD"] = TextureCoordinate
    gTextureMappers["NEW_GEOMETRY"] = NewGeometry
    
    gMaterialMappers["OUTPUT_MATERIAL"] = OutputMaterial

    # Materials
    gMaterialMappers["BSDF_PRINCIPLED"] = BsdfPrincipled
    gMaterialMappers["MIX_SHADER"] = MixShader

    gMaterialMappers["BSDF_DIFFUSE"] = BsdfDiffuse
    gMaterialMappers["BSDF_GLASS"] = BsdfGalss
    gMaterialMappers["BSDF_GLOSSY"] = BsdfGlossy
    gMaterialMappers["BSDF_TRANSPARENT"] = BsdfTransparent
    gMaterialMappers["EMISSION"] = Emission

    gMaterialMappers["REROUTE"] = RerouteMaterial

    # Textures
    gTextureMappers["TEX_IMAGE"] = ImageTexture
    gTextureMappers["TEX_BRICK"] = BuiltInTexture
    gTextureMappers["TEX_CHECKER"] = BuiltInTexture
    gTextureMappers["TEX_GRADIENT"] = BuiltInTexture
    gTextureMappers["TEX_ENVIRONMENT"] = BuiltInTexture
    gTextureMappers["TEX_IES"] = BuiltInTexture
    gTextureMappers["TEX_MAGIC"] = BuiltInTexture
    gTextureMappers["TEX_MUSGRAVE"] = BuiltInTexture
    gTextureMappers["TEX_NOISE"] = BuiltInTexture
    gTextureMappers["TEX_POINTDENSITY"] = BuiltInTexture
    gTextureMappers["TEX_SKY"] = BuiltInTexture
    gTextureMappers["TEX_VORONOI"] = BuiltInTexture
    gTextureMappers["TEX_WAVE"] = BuiltInTexture
    gTextureMappers["TEX_WHITE_NOISE"] = BuiltInTexture

    # Colors
    gTextureMappers["BRIGHTCONTRAST"] = BrightContrast
    gTextureMappers["GAMMA"] = Gamma
    gTextureMappers["HUE_SAT"] = HueSat
    gTextureMappers["INVERT"] = Invert
    gTextureMappers["MIX_RGB"] = MixRGB
    gTextureMappers["CURVE_RGB"] = RGBCurve

    # Vectors
    gTextureMappers["BUMP"] = Bump
    gTextureMappers["NORMAL_MAP"] = NormalMap
    gTextureMappers["MAPPING"] = Mapping

    # Converters
    gTextureMappers["CLAMP"] = ColorRamp
    gTextureMappers["VALTORGB"] = ColorRamp
    gTextureMappers["SEPXYZ"] = SeperateXYZ
    gTextureMappers["COMBXYZ"] = CombineXYZ
    gTextureMappers["SEPRGB"] = SeperateRGB
    gTextureMappers["COMBRGB"] = CombineRGB

    # Others

    gTextureMappers["REROUTE"] = RerouteTexture

    # Groups
    # gMaterialMappers["GROUP"] = GroupMaterial
    gTextureMappers["GROUP"] = GroupTexture

    Log("Finished")
    return

def RenameMaterials() -> None:
    Log("Renaming all materials...")
    listOfMaterials = list()
    for mtl in bpy.data.materials:
        listOfMaterials.append(mtl)
    for mtl in listOfMaterials:
        newName = mtl.name.strip()
        newName = re.sub("[&<>\" ]", "_", newName)  # XML
        newName = re.sub("[%!*/\\|?':]", "_", newName)  # Path
        if newName != mtl.name:
            Log("Renaming %s as %s" % (mtl.name, newName))
            mtl.name = newName
    
    Log("Finished")
    return

def MakeTempDirs():
    Log("Making temp dirs...")
    global gTempDir
    global gTextureDir

    tempRoot = os.environ["TEMP"]
    tempDir = MakeUniqueName(os.path.join(
        tempRoot, "d5a_temp_%d"), lambda v: not os.path.exists(v))
    if os.path.exists(tempDir):
        shutil.rmtree(tempDir)
    if os.path.exists(tempDir):
        os.remove(tempDir)
    os.mkdir(tempDir)
    textureDir = os.path.join(tempDir, "textures")
    os.mkdir(textureDir)

    gTempDir = tempDir
    gTextureDir = textureDir
    
    Log("Finished")
    return

def CollectObjects():
    def SortUVMaps(obj: bpy.types.Object) -> None:
        uvLayers = obj.data.uv_layers
        if len(uvLayers) == 0:
            obj.data.uv_layers.new()
            return
        renderUVIndex = None
        for i in range(len(uvLayers)):
            if uvLayers[i].active_render:
                renderUVIndex = i
                break
        if renderUVIndex == None:
            uvLayers[0].active_render = True
            renderUVIndex = 0

        rotateUVMaps(uvLayers, renderUVIndex)
        uvLayers.active_index = 0
        return

    def AreObjectModifiersIdentical(obj1, obj2) -> bool:
        def AreModifiersIdentical(mod1, mod2):
            if mod1 == None and mod2 == None:
                return True
            elif mod1 == None or mod2 == None:
                return False
            else:
                if mod1.type != mod2.type:
                    return False
                else:
                    for prop in mod1.bl_rna.properties.keys():
                        if prop != "name":
                            if getattr(mod1, prop, True) != getattr(mod2, prop, False):
                                return False
            return True
        if (len(obj1.modifiers) != len(obj2.modifiers)):
            return False
        for idx in range(len(obj1.modifiers)):
            if not AreModifiersIdentical(obj1.modifiers[idx], obj2.modifiers[idx]):
                return False
        return True

    Log("Collecting objects...")

    selectedObjects = list()

    for obj in bpy.context.view_layer.objects:
        if (not goExportSelected or obj.select_get()) and obj.visible_get():
            selectedObjects.append(obj)

    Log("%d base objects collected. Instantiating objects..." % len(selectedObjects))

    # Fix Context
    for x in range(2):
        if bpy.ops.object.select_all.poll():
            bpy.ops.object.select_all(action="DESELECT")
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set()

    instIdx = 0
    instTotal = len(selectedObjects)

    for obj in selectedObjects:
        instIdx += 1
        Log("%d/%d: Instantiating %s" % (instIdx, instTotal, obj.name))
        if obj.type == "EMPTY" and obj.instance_collection != None:
            if len(obj.instance_collection.objects) > 0:
                selectObject(obj)
                bpy.ops.object.duplicates_make_real(
                    use_base_parent=True, use_hierarchy=True)
                instanceObjects = list()
                for x in bpy.context.view_layer.objects.selected:
                    instanceObjects.append(x)
                bpy.ops.object.make_local(type="ALL")
                for instancedObj in instanceObjects:
                    if instancedObj not in selectedObjects and instancedObj.type == "MESH":
                        selectedObjects.append(instancedObj)

    Log("Instantiation finished. %d objects collected." % len(selectedObjects))
    Log("Analysing instances...")

    meshDict = dict()

    for obj in selectedObjects:
        if obj.type == "MESH":
            if obj.data == None or len(obj.data.polygons) == 0:
                continue
            selectObject(obj)
            # TODO: Resolve selectable, visible, etc
            if not bpy.ops.object.mode_set.poll():
                Log("Unable to export: %s" % obj.name)
                continue
            if obj.data not in meshDict.keys():
                meshDict[obj.data] = list()
            meshDict[obj.data].append(obj)

    instanceGroups = list()
    for group in meshDict.values():
        if len(group) == 1:
            instanceGroups.append(group)
            continue

        subgroups = list()
        for obj in group:
            existSame = False
            for subgroup in subgroups:
                if (AreObjectModifiersIdentical(obj, subgroup[0])):
                    subgroup.append(obj)
                    existSame = True
                    break
            if not existSame:
                newGroup = list()
                newGroup.append(obj)
                subgroups.append(newGroup)

        for subgroup in subgroups:
            copiedMesh = subgroup[0].data.copy()
            for obj in subgroup:
                obj.data = copiedMesh
            instanceGroups.append(subgroup)

    Log("Converting objects to mesh...")

    for group in instanceGroups:
        base = group[0]
        SortUVMaps(base)
        base.data.validate()
        base.data.validate_material_indices()
        if len(base.modifiers) > 0:
            Log("Converting object to mesh: %s" % base.name)
            selectObject(base)
            bpy.ops.object.convert()
            for inst in group[1:]:
                while len(inst.modifiers) > 0:
                    inst.modifiers.remove(inst.modifiers[0])

    Log("Finished")
    return instanceGroups

def CollectMaterials(instanceGroups):
    Log("Collecting materials...")

    allMaterials = list()
    for group in instanceGroups:
        base = group[0]
        for mtlSlot in base.material_slots:
            if mtlSlot.material not in allMaterials:
                allMaterials.append(mtlSlot.material)

    simpleD5Materials = list()
    complexBlenderMaterials = list()

    for mtl in allMaterials:
        gc.collect()
        metaMaterial = MapMaterial(mtl)
        if metaMaterial != None:
            if metaMaterial.NeedsBake:
                complexBlenderMaterials.append(mtl)
            else:
                simpleD5Materials.append(metaMaterial.ToD5Material(mtl.name))


    Log("Finished: %d simple materials and %d complex materials collected." % (len(simpleD5Materials), len(complexBlenderMaterials)))
    return simpleD5Materials, complexBlenderMaterials

def PrepareFbx(instanceGroups, complexBlenderMaterials):
    Log("Preparing to export fbx file...")

    bakingList = dict()  # <obj: (slotId, oriMtl)>
    clonedMaterials = list()

    for group in instanceGroups:
        base = group[0]
        for mtlSlotId in range(len(base.material_slots)):
            originalMaterial = base.material_slots[mtlSlotId].material
            if originalMaterial == None:
                base.material_slots[mtlSlotId].material = bpy.data.materials.new(
                    name="DefaultMaterial")
            elif not originalMaterial.use_nodes:
                originalMaterial.use_nodes = True
            elif originalMaterial in complexBlenderMaterials:
                clonedMaterial = originalMaterial.copy()
                clonedMaterials.append(originalMaterial)
                if base not in bakingList.keys():
                    bakingList[base] = list()
                bakingList[base].append((mtlSlotId, originalMaterial))

                base.material_slots[mtlSlotId].material = clonedMaterial
                for inst in group[1:]:
                    if len(inst.material_slots) == len(base.material_slots) and inst.material_slots[mtlSlotId].material == originalMaterial:
                        inst.material_slots[mtlSlotId].material = clonedMaterial

    for obj in bakingList:
        selectObject(obj)
        uvLayers = obj.data.uv_layers
        layerToUnwrap = uvLayers.new(name="D5Bake", do_init=True)
        rotateUVMaps(uvLayers, len(uvLayers) - 1)
        uvLayers.active_index = 0
        uvLayers[0].active = True
        uvLayers[1].active_render = True

        for slotId, _ in bakingList[obj]:
            Log("Unwrapping UV for object: %s, mateiral: %s" % (obj.name, obj.material_slots[slotId].material.name))

            bpy.ops.object.mode_set_with_submode(
                mode="EDIT", mesh_select_mode={"FACE"})
            bm = bmesh.from_edit_mesh(obj.data)

            for face in bm.faces:
                if face.material_index == slotId:
                    face.select_set(True)
                else:
                    face.select_set(False)

            bmesh.update_edit_mesh(obj.data)
            bpy.ops.uv.smart_project()
            bpy.ops.object.mode_set(mode="OBJECT")

    return bakingList, clonedMaterials

def DoBake(bakingList):
    def AdjustBakeSettings():
        bpy.context.scene.render.engine = "CYCLES"
        bpy.context.scene.cycles.samples = 8
        bpy.context.scene.render.bake_samples = 64
        bpy.context.scene.render.tile_x = min(goTextureSize, 1024)
        bpy.context.scene.render.tile_y = min(goTextureSize, 1024)
        bpy.context.scene.render.image_settings.file_format = "PNG"
        return

    Log("Baking objects...")

    AdjustBakeSettings()

    complexD5Materials = list()

    objIdx = 0
    objTotal = len(bakingList.keys())
    for obj in bakingList.keys():
        Log("%d/%d: Baking object %s" % (objIdx, objTotal, obj.name))
        gc.collect()
        selectObject(obj)

        nodeList = list()
        imageList = list()
        originalMaterialList = list()
        metaMaterialList = list()

        for slotId in range(len(obj.material_slots)):
            originalMaterialList.append(obj.material_slots[slotId].material)
            obj.material_slots[slotId].material = obj.material_slots[slotId].material.copy(
            )
            mtl = obj.material_slots[slotId].material

            imageNode = mtl.node_tree.nodes.new("ShaderNodeTexImage")
            newImage = bpy.data.images.new(
                "D5A_Baking", goTextureSize, goTextureSize)
            newImage.file_format = "PNG"
            imageNode.image = newImage

            nodeList.append(imageNode)
            imageList.append(newImage)
            metaMaterialList.append(MapMaterial(mtl))

        channelDict = dict()
        for channel in D5TextureKind.D5TextureAll:
            channelDict[channel] = list()
            for slotId, _ in bakingList[obj]:
                if metaMaterialList[slotId].Textures[channel] != None:
                    if metaMaterialList[slotId].Textures[channel].OutSocketToBake != None:
                        channelDict[channel].append(slotId)
                    else:
                        Log("Fatal Error: OutSocketToBake is None")

        for channel in channelDict.keys():
            if len(channelDict[channel]) > 0:
                for slotId in channelDict[channel]:
                    mtl = obj.material_slots[slotId].material
                    metaTex = metaMaterialList[slotId].Textures[channel]

                    nodeTree = mtl.node_tree
                    outputNode = nodeTree.get_output_node("ALL")

                    # Remove original link to output node
                    for link in nodeTree.links:
                        if link.to_node == outputNode:
                            nodeTree.links.remove(link)

                    if channel == D5TextureKind.D5TextureBump:
                        bsdfPrincipled = nodeTree.nodes.new(
                            "ShaderNodeBsdfPrincipled")
                        nodeTree.links.new(
                            metaTex.OutSocketToBake, bsdfPrincipled.inputs["Normal"])
                        nodeTree.links.new(
                            bsdfPrincipled.outputs["BSDF"], outputNode.inputs["Surface"])
                    else:
                        nodeTree.links.new(
                            metaTex.OutSocketToBake, outputNode.inputs["Surface"])

                for slotId in range(len(obj.material_slots)):
                    nodes = obj.material_slots[slotId].material.node_tree.nodes
                    for node in nodes:
                        node.select = False
                    nodeList[slotId].select = True
                    nodes.active = nodeList[slotId]


                Log("Baking object: %s, channel: %s" % (obj.name, channel))

                if channel == D5TextureKind.D5TextureBump:
                    bpy.ops.object.bake(type="NORMAL")
                else:
                    bpy.ops.object.bake(type="EMIT")

                for slotId in channelDict[channel]:
                    tmpFile = os.path.join(gTempDir, "temp.png")
                    imageList[slotId].save_render(tmpFile)
                    pixels = ReadImageFromFile(tmpFile)
                    os.remove(tmpFile)
                    newTex = MetaTexture()
                    newTex.Pixels = pixels
                    metaMaterialList[slotId].Textures[channel] = newTex

        for slotId in range(len(obj.material_slots)):
            tmpMtl = obj.material_slots[slotId].material
            obj.material_slots[slotId].material = originalMaterialList[slotId]
            bpy.data.materials.remove(tmpMtl)

        for image in imageList:
            bpy.data.images.remove(image)

        for slotId in range(len(obj.material_slots)):
            metaMaterialList[slotId].Normalize()
            if metaMaterialList[slotId].NeedsBake:
                Log("Failed to bake %s, %s" %
                      (obj.name, obj.material_slots[slotId].material.name))
            else:
                complexD5Materials.append(metaMaterialList[slotId].ToD5Material(
                    obj.material_slots[slotId].material.name))

    return complexD5Materials

def ExportFBX(instanceGroups):
    bpy.ops.object.select_all(action="DESELECT")
    for group in instanceGroups:
        for obj in group:
            obj.select_set(True)

    basename = os.path.basename(goFilePath)
    if basename.lower().endswith(".d5a"):
        basename = basename[:-4]
    if basename == "":
        basename = "model"
    fbxPath = os.path.join(gTempDir, "%s.fbx" % basename)
    Log("Saving fbx file to: %s" % fbxPath)
    bpy.ops.export_scene.fbx(filepath=fbxPath, bake_anim=False,
                             bake_space_transform=goUseTransform, use_selection=True)
    return

def SaveXML(d5Materials):
    d5MaterialsElem = ET.Element("D5Materials")
    for elem in d5Materials:
        d5MaterialsElem.append(elem.ToXMLNode())
    elemTree = ET.ElementTree(d5MaterialsElem)
    xmlPath = os.path.join(gTempDir, "d5material.xml")
    Log("Writing materials into: %s" % xmlPath)
    elemTree.write(xmlPath, encoding="utf-8", xml_declaration=True)

def MakeD5A():
    d5aPath = goFilePath
    if not d5aPath.lower().endswith(".d5a"):
        if d5aPath.endswith('/') or d5aPath.endswith('\\'):
            d5aPath = d5aPath + "ExportNoName.d5a"
        else:
            d5aPath = d5aPath = ".d5a"

    Log("Creating D5A file: %s" % d5aPath)

    z = zipfile.ZipFile(d5aPath, "w", zipfile.ZIP_DEFLATED)
    for dirpath, dirnames, filenames in os.walk(gTempDir):
        for f in filenames:
            item = os.path.join(dirpath, f)
            z.write(item, item.replace(gTempDir, ""))
    z.close()
    return

def ClearTempDirs():
    global gTempDir
    try:
        if gTempDir and os.path.exists(gTempDir):
            shutil.rmtree(gTempDir, True)
        if os.path.exists(gTextureDir):
            os.remove(gTempDir)
        if os.path.exists(gTempDir):
            os.remove(gTempDir)
    except:
        pass
    return

def RevertChanges():
    Log("Reverting changes...")
    if bpy.ops.wm.revert_mainfile.poll():
        bpy.ops.wm.revert_mainfile()
        Log("Succeeded.")
    else:
        Log("Failed.")
    return

# End - D5ABuilders
# ----------------------------------------------


def DoExport(filepath: str, textureSize: int, exportSelected: bool, bakeGroupNodes: bool) -> None:
    global goFilePath
    global goTextureSize
    global goExportSelected
    global goBakeGroupNodes
    goFilePath = filepath
    goTextureSize = textureSize
    goExportSelected = exportSelected
    goBakeGroupNodes = bakeGroupNodes

    Log("ExportOptions:")
    LogOptions = lambda name, value : Log("\t%-24s:\t%s" % (name, str(value)))
    LogOptions("Debug Mode", gDebugMode)
    LogOptions("File Path", goFilePath)
    LogOptions("Texture Size", goTextureSize)
    LogOptions("Export Selected", goExportSelected)
    LogOptions("Use Transform", goUseTransform)
    LogOptions("Bake Group Nodes", goBakeGroupNodes)
    LogOptions("Iamge Format", gIamgeFormat)


    RegisterMappers()
    RenameMaterials()
    MakeTempDirs()
    instanceGroups = CollectObjects()
    simpleD5Materials, complexBlenderMaterials = CollectMaterials(
        instanceGroups)
    bakingList, clonedMaterials = PrepareFbx(
        instanceGroups, complexBlenderMaterials)
    ExportFBX(instanceGroups)
    complexD5Materials = DoBake(bakingList)

    allD5Materials = list()
    for d5Mtl in simpleD5Materials:
        allD5Materials.append(d5Mtl)
    for d5Mtl in complexD5Materials:
        allD5Materials.append(d5Mtl)

    SaveXML(allD5Materials)
    MakeD5A()
    ClearTempDirs()
    ClearTempDirs()
    RevertChanges()

    return True


def ExportD5AMain(filepath: str, textureSize: int, exportSelected: bool, bakeGroupNodes: bool, writeLog: bool) -> str:
    global gLogFile
    try:
        logPath = filepath + ".log"
        if writeLog:
            gLogFile = open(logPath, "w")
        else:
            gLogFile = io.StringIO()

        exceptInfo = None
        result = False
        result = DoExport(filepath, textureSize, exportSelected, bakeGroupNodes)
    except:
        exceptInfo = traceback.format_exc()
        Log(exceptInfo)
    finally:
        if writeLog:
            gLogFile.close()
        if result == False and not writeLog:
            logFile = open(filepath + ".log", "w")
            logFile.write(gLogFile.getvalue())
            logFile.close()
    return exceptInfo
