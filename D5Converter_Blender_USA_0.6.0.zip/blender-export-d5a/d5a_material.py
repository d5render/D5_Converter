import enum
import xml.etree.ElementTree as ET


def GetValue(value, default):
    if value == None:
        return default
    elif type(value) == float:
        return "%.3f" % value
    return value


class D5Color():
    def __init__(self, r = 255, g = 255, b = 255):
        self.Red = r
        self.Green = g
        self.Blue = b
        return 

    @staticmethod
    def FromFloat(r = 1.0, g = 1.0, b = 1.0):
        return D5Color(int(r * 255), int(g * 255), int(b * 255))

    @staticmethod
    def FromFloatArray(floatArray):
        ftu8 = lambda x: int(x * 255.0)
        return D5Color(ftu8(floatArray[0]), ftu8(floatArray[1]), ftu8(floatArray[2]))

    def ToFloatArray(self):
        u8tf = lambda x: float(x) / 255.0
        return [u8tf(self.Red), u8tf(self.Green), u8tf(self.Blue)]

    def ToString(self):
        clip = lambda x : min(255, max(0 , x))
        self.Red = clip(self.Red)
        self.Green = clip(self.Green)
        self.Blue = clip(self.Blue)
        return ("#%02X%02X%02X" % (self.Red, self.Green, self.Blue))


# class D5TextureKind(enum.Enum):
class D5TextureKind():
    D5TextureDiffuse = "Diffuse"
    D5TextureMask = "Mask"
    D5TextureBump = "Bump"
    D5TextureRoughness = "Roughness"
    D5TextureSpecular = "Specular"
    D5TextureMetal = "Metal"
    D5TextureAll = [
        D5TextureDiffuse,
        D5TextureMask,
        D5TextureBump,
        D5TextureRoughness,
        D5TextureSpecular,
        D5TextureMetal
    ]


class D5Texture():
    def __init__(self):
        # self.Kind: D5TextureKind = D5TextureKind.D5TextureDiffuse
        self.Source: str = None
        self.FilePath: str = None
        self.Brightness: float = None
        self.IsInverted: bool = None
        self.UseExplicitTransformation: bool = None
        self.Width: float = None
        self.Height: float = None
        self.U_Offset: float = None
        self.V_Offset: float = None
        self.Rotation: float = None
        return

    def ToXMLNode(self, texKind):
        elem = ET.Element("%sTexture" % texKind)
        ET.SubElement(elem, "Source").text = GetValue(self.Source, "TEXTURE_PATH_ABSOLUTE")
        ET.SubElement(elem, "Filepath").text = GetValue(self.FilePath, "")
        ET.SubElement(elem, "Brightness").text = str(GetValue(self.Brightness, 1.0))
        ET.SubElement(elem, "IsInverted").text = str(GetValue(self.IsInverted, False)).lower()
        ET.SubElement(elem, "UseExplicitTransformation").text = str(GetValue(self.UseExplicitTransformation, True)).lower()
        ET.SubElement(elem, "Width").text = str(GetValue(self.Width, 1.0))
        ET.SubElement(elem, "Height").text = str(GetValue(self.Height, 1.0))
        ET.SubElement(elem, "U_Offset").text = str(GetValue(self.U_Offset, 0.0))
        ET.SubElement(elem, "V_Offset").text = str(GetValue(self.V_Offset, 0.0))
        ET.SubElement(elem, "Rotation").text = str(GetValue(self.Rotation, 0.0))
        return elem


class D5Material():
    def __init__(self):
        self.Name: str = None
        self.Type: str = None
        self.Opacity: float = None
        self.DiffuseColor: D5Color = None
        self.ImageFade: int = None # Reserved
        self.EmissiveColor: D5Color = None
        self.EmissiveStrength: float = None # (0.0, 10.0)
        self.TintColor: D5Color = None
        self.Roughness: float = None
        self.BumpAmount: float = None # (0.0, 10.0) -> (0.0, 1.0)
        self.Metallic: float = None
        self.Specular: float = None
        self.IndexOfRefraction: float = None # (0.0, 3.0)
        # self.IsSolidGlass: bool = None
        # self.BumpMapType: str = None
        self.TextureWidth: float = None
        self.TextureHeight: float = None
        self.Textures: dict = dict()
        return

    def ToXMLNode(self):
        elem = ET.Element("Material")
        ET.SubElement(elem, "Name").text = GetValue(self.Name, "Default")
        ET.SubElement(elem, "Type").text = GetValue(self.Type, "Custom")
        ET.SubElement(elem, "Opacity").text = str(GetValue(self.Opacity, 1.0))
        ET.SubElement(elem, "DiffuseColor").text =  GetValue(self.DiffuseColor, D5Color()).ToString()
        ET.SubElement(elem, "ImageFade").text = str(GetValue(self.ImageFade, 0))
        ET.SubElement(elem, "EmissiveColor").text = GetValue(self.EmissiveColor, D5Color()).ToString()
        ET.SubElement(elem, "EmissiveStrength").text = str(GetValue(self.EmissiveStrength, 0.0))
        ET.SubElement(elem, "TintColor").text = GetValue(self.TintColor, D5Color()).ToString()
        ET.SubElement(elem, "Roughness").text = str(GetValue(self.Roughness, 0.4))
        ET.SubElement(elem, "BumpAmount").text = str(GetValue(self.BumpAmount, 0.1))
        ET.SubElement(elem, "Metallic").text = str(GetValue(self.Metallic, 0.0))
        ET.SubElement(elem, "Specular").text = str(GetValue(self.Specular, 0.3))
        ET.SubElement(elem, "IndexOfRefraction").text = str(GetValue(self.IndexOfRefraction, 1.52))
        # ET.SubElement(elem, "IsSolidGlass").text = str(GetValue(self.IsSolidGlass, False)).lower()
        # ET.SubElement(elem, "BumpMapType").text = GetValue(self.BumpMapType, "HEIGHT_MAP")
        ET.SubElement(elem, "TextureWidth").text = str(GetValue(self.TextureWidth, 1.0))
        ET.SubElement(elem, "TextureHeight").text = str(GetValue(self.TextureHeight, 1.0))
        for texKey in self.Textures.keys():
            elem.append(self.Textures[texKey].ToXMLNode(texKey))
        return elem


if __name__ == "__main__":
    print(D5Color().ToFloatArray())