import io
import json
import os
import shutil
import zipfile
import hashlib
import sys
from typing import List, Tuple
from urllib import request


def NeedsUpdate(localVersion: str, remoteVersion: str) -> bool:
    localVersion = [int(d) for d in localVersion.split('.')]
    remoteVersion = [int(d) for d in remoteVersion.split('.')]
    maxLen = max(len(localVersion), len(remoteVersion))
    for ver in [localVersion, remoteVersion]:
        while len(ver) < maxLen:
            ver.append(0)
    for i in range(maxLen):
        if localVersion[i] < remoteVersion[i]:
            return True
        elif localVersion[i] > remoteVersion[i]:
            return False
        else:
            continue
    return False

def ExtractFiles(updatePack: zipfile.ZipFile):
    pluginDir = os.path.dirname(__file__)
    try:
        updateDir = os.path.join(pluginDir, "update")
        if os.path.exists(updateDir):
            if os.path.isfile(updateDir):
                os.remove(updateDir)
            else:
                shutil.rmtree(updateDir, True)
        if not os.path.exists(updateDir):
            os.mkdir(updateDir)
        updatePack.extractall(updateDir)
        
        packDir = os.path.join(updateDir, "blender-export-d5a")
        for f in os.listdir(packDir):
            fpath = os.path.join(packDir, f)
            dstPath = os.path.join(pluginDir, os.path.basename(f))
            if os.path.isdir(fpath):
                if not os.path.exists(dstPath):
                    shutil.copytree(fpath, dstPath)
            elif f.lower().endswith(".py"):
                shutil.copy(fpath, dstPath)
    finally:
        shutil.rmtree(updateDir, True)
    return


def UpdatePlugin():
    try:
        from . import d5a_support
        localVersion = d5a_support.D5A_BLENDER_PLUGIN_VERSION
        reqUrl = d5a_support.UPDATE_CHECK_URL
        downloadUrlBase = d5a_support.UPDATE_DOWNLOAD_URL

        updateData = request.urlopen(reqUrl).read()
        updateInfo = json.loads(updateData)
        remoteVersion = updateInfo["version"]
        if NeedsUpdate(localVersion, remoteVersion):
            packName = updateInfo["url"]
            downloadUrl = os.path.join(downloadUrlBase, packName)
            updatePack = request.urlopen(downloadUrl).read()
            md5 = hashlib.md5(updatePack).hexdigest()
            if md5 != updateInfo["md5"]:
                return None
            updatePack = io.BytesIO(updatePack)
            updatePack = zipfile.ZipFile(updatePack)
            ExtractFiles(updatePack)
            return "D5 Convertor for Blender is updated to: %s" % updateInfo["version"]
    except Exception as ex:
        print(ex)
